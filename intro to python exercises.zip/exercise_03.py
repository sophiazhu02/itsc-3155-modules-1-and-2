num = int(input("Enter an integer greater than 1: "))
for i in range(num + 1):
    cube = i ** 3
    print(f"The cube of {i} is {cube}")